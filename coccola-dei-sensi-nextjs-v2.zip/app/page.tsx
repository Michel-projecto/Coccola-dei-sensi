'use client';
import { Card, CardContent } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Instagram } from "lucide-react";
import { useState } from "react";

const availableDates = [
  new Date(2025, 4, 24), new Date(2025, 4, 25),
  new Date(2025, 5, 7), new Date(2025, 5, 8),
  new Date(2025, 5, 28), new Date(2025, 5, 29),
  new Date(2025, 6, 26), new Date(2025, 6, 27),
  new Date(2025, 7, 1), new Date(2025, 7, 2),
  new Date(2025, 7, 16), new Date(2025, 7, 17),
  new Date(2025, 7, 23), new Date(2025, 7, 24),
  new Date(2025, 7, 30), new Date(2025, 7, 31),
  new Date(2025, 8, 13), new Date(2025, 8, 14),
  new Date(2025, 8, 20), new Date(2025, 8, 21),
  new Date(2025, 9, 4), new Date(2025, 9, 5),
  new Date(2025, 9, 11), new Date(2025, 9, 12),
  new Date(2025, 9, 18), new Date(2025, 9, 19),
  new Date(2025, 9, 25), new Date(2025, 9, 26),
];

function isDateAvailable(date: Date) {
  return availableDates.some(
    (d) => d.getFullYear() === date.getFullYear() &&
           d.getMonth() === date.getMonth() &&
           d.getDate() === date.getDate()
  );
}

export default function ExperiencePage() {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const formattedDate = selectedDate
    ? selectedDate.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })
    : null;

  const message = formattedDate
    ? `Hello, I would like to request the weekend of ${formattedDate} in Ticino-Lugano.`
    : "";

  const whatsappLink = `https://wa.me/41797062481?text=${encodeURIComponent(message)}`;
  const emailLink = `mailto:barmicu@yahoo.com?subject=Weekend%20Booking&body=${encodeURIComponent(message)}`;

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">A Weekend of Connection</h1>
        <p className="text-lg">
          Spend a weekend with me in the natural beauty of Ticino-Lugano — where I dedicate my full attention to you. This is an invitation to slow down, to feel, to reconnect with your senses. Through nourishing food, mountain hikes, silence, and shared presence, you'll rediscover your own rhythm, self-consciousness, and inner availability to feel.
        </p>
        <p className="text-md text-muted-foreground">
          I speak five languages and warmly welcome guests from all cultures and backgrounds.
        </p>
      </section>

      <section className="text-center space-y-4">
        <img src="/images/profile.jpg" alt="Michel Barman" className="w-40 h-40 mx-auto rounded-full object-cover" />
        <p className="text-md">
          I’m Michel, a 52-year-old father of two young men (24 and 20). I work as a consultant, and over the past five years, I’ve devoted significant time to personal development through self-consciousness practices and workshops. I’m passionate about presence, emotional intelligence, and authentic connection — both with ourselves and others. I bring warmth, attentiveness, and openness into every encounter, and I believe in the power of nature and silence to guide us home to ourselves.
        </p>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Available Weekends</h2>
        <Card>
          <CardContent className="p-4">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              className="rounded-md border"
              disabled={(date) => !isDateAvailable(date)}
            />
          </CardContent>
        </Card>
        {selectedDate && (
          <div className="space-y-2">
            <p className="text-md">You selected: <strong>{formattedDate}</strong></p>
            <div className="space-x-4">
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="text-green-600 underline">
                Request via WhatsApp
              </a>
              <a href={emailLink} className="text-blue-600 underline">
                Request via Email
              </a>
            </div>
          </div>
        )}
      </section>

      <section className="space-y-2">
        <h2 className="text-2xl font-semibold">Contact for Booking</h2>
        <ul className="list-disc list-inside">
          <li>Email: <a href="mailto:barmicu@yahoo.com" className="text-blue-600">barmicu@yahoo.com</a></li>
          <li>Phone: +41 79 706 24 81</li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="text-2xl font-semibold">Follow on Instagram</h2>
        <div className="flex items-center space-x-2">
          <Instagram className="w-6 h-6 text-pink-600" />
          <a href="https://instagram.com/michel.barman" target="_blank" rel="noopener noreferrer" className="text-blue-600">@michel.barman</a>
        </div>
      </section>
    </div>
  );
}